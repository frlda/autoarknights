from nonebot.plugin import PluginMetadata
from .handlers import *
from .image_deliver import *  # 添加这一行来启动图片转发服务

__plugin_meta__ = PluginMetadata(
    name="autoarknights",
    description="明日方舟账号管理插件",
    usage="""
    账号管理:
    - 绑定游戏账号 [账号] [密码] [服务器]
    - 删除游戏账号 [账号序号]
    - 查看账号列表
    - 设置关卡 [账号序号] [关卡列表]
    ...
    """,
    type="application",
    homepage="https://github.com/your-username/nonebot-plugin-autoarknights",
    supported_adapters={"~onebot.v11"},
)