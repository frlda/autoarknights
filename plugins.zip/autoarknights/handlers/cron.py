import asyncio
import nonebot
from nonebot import on_command, require, get_driver
from nonebot.log import logger
from nonebot.permission import SUPERUSER
from nonebot.adapters.onebot.v11 import Bot, MessageEvent
from datetime import datetime
from sqlmodel import Session, select, distinct
from typing import List, Set, Optional, Tuple, Union
import subprocess
from pathlib import Path

# 导入数据模型和配置
from ..database import ArkAccount, engine
from ..config import arknight_update_times as update_times 

# 注册定时任务
scheduler = require("nonebot_plugin_apscheduler").scheduler

# 获取 dlt.py 的路径
DLT_PATH = Path(__file__).parent.parent / "cron" / "dlt.py"

class AccountManager:
    @staticmethod
    async def get_devices() -> List[int]:
        """获取所有不重复的设备号"""
        try:
            with Session(engine) as session:
                statement = select(ArkAccount.device).distinct()
                results = session.exec(statement).all()
                return sorted(list(set(dev for dev in results if dev is not None)))
        except Exception as e:
            logger.error(f"Error getting devices: {str(e)}")
            return []

    @staticmethod
    async def start_fight(device: Union[str, int]) -> Tuple[bool, str]:
        """开始战斗(使用异步子进程)"""
        try:
            cmd = ["python", str(DLT_PATH), "mode", str(device), "restart"]
            logger.info(f"Starting fight on device {device}")
            
            # 使用异步子进程
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await proc.communicate()
            
            if proc.returncode != 0:
                logger.error(f"Failed to start fight on device {device}: {stderr.decode()}")
                return False, f"启动战斗失败: {stderr.decode()}"
            
            logger.info(f"Successfully started fight on device {device}")
            return True, "战斗已启动"
                
        except Exception as e:
            logger.error(f"Error starting fight on device {device}: {str(e)}")
            return False, f"启动战斗时发生错误: {str(e)}"

    @staticmethod
    async def update_accounts() -> Tuple[bool, str]:
        try:
            all_devices = await AccountManager.get_devices()
            if not all_devices:
                return False, "未找到可用设备"

            total_success = 0
            total_fail = 0
            total_delete = 0
            response_messages: List[str] = []
            
            for device in all_devices:
                with Session(engine) as session:
                    # 获取同一设备的所有账号
                    statement = select(ArkAccount).where(
                        ArkAccount.device == device
                    )
                    accounts = session.exec(statement).all()
                    
                    device_success = 0
                    device_fail = 0
                    device_delete = 0
                    
                    # 为设备上的所有账号分配连续的idx
                    device_idx = 1  # 从1开始计数
                    
                    # 处理该设备上的所有账号
                    for account in accounts:
                        try:
                            cmd = [
                                "python", str(DLT_PATH),
                                "mode", str(device),
                                "user", str(account.username),
                                str(account.password) if account.password else "''",
                            ]
                            
                            # 使用设备级别的连续idx
                            cmd.append(f"--idx={device_idx}")
                            device_idx += 1  # 递增idx

                            if account.password:
                                if account.server == "bilibili":
                                    cmd.append("--server")
                                if account.quests:
                                    cmd.extend([f"--fight='{account.quests}'"])
                            
                            logger.info(f"Executing command: {' '.join(cmd)}")
                            result = subprocess.run(cmd, capture_output=True, text=True)
                            
                            if result.returncode == 0:
                                if account.password:
                                    device_success += 1
                                else:
                                    device_delete += 1
                                account.updated_at = datetime.now()
                                session.add(account)
                            else:
                                device_fail += 1
                                logger.error(f"Command failed: {result.stderr}")
                                
                        except Exception as e:
                            device_fail += 1
                            logger.error(f"Error processing account: {str(e)}")
                            continue
                    
                    session.commit()
                    
                    total_success += device_success
                    total_fail += device_fail
                    total_delete += device_delete
                    
                    response_messages.append(
                        f"设备 {device}: "
                        f"更新成功{device_success}个, "
                        f"删除成功{device_delete}个, "
                        f"失败{device_fail}个"
                    )
            
            final_message = "\n".join([
                f"总计: 更新成功{total_success}个, 删除or冻结成功{total_delete}个, 失败{total_fail}个",
                "详细信息:",
                *response_messages
            ])
            
            return True, final_message
                        
        except Exception as e:
            error_msg = f"更新过程发生错误: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
        
# 注册定时任务
for update_time in update_times:
    hour, minute = update_time.split(":")
    
    @scheduler.scheduled_job("cron", hour=int(hour), minute=int(minute))
    async def scheduled_update() -> None:
        """定时更新任务"""
        try:
            logger.info(f"Starting scheduled account update at {datetime.now()}")
            success, msg = await AccountManager.update_accounts()
            logger.info(f"Scheduled update completed: {msg}")
            
            # 等待一段时间确保更新完成
            await asyncio.sleep(30)
            
            logger.info(f"Starting fights at {datetime.now()}")
            device_list = await AccountManager.get_devices()
            if device_list:
                for dev in device_list:
                    try:
                        success, msg = await AccountManager.start_fight(dev)
                        logger.info(f"Fight started on device {dev}: {msg}")
                        # 每个设备启动之间添加间隔，避免并发问题
                        await asyncio.sleep(10)
                    except Exception as e:
                        logger.error(f"Error starting fight on device {dev}: {str(e)}")
                        continue
            
        except Exception as e:
            logger.error(f"Error in scheduled update: {str(e)}")
            return

# 命令处理器
update_handler = on_command("更新所有账号", permission=SUPERUSER, priority=5)
fight_handler = on_command("一键战斗", permission=SUPERUSER, priority=5)
device_handler = on_command("获取设备", permission=SUPERUSER, priority=5)
screenshot_handler = on_command("获取截图", permission=SUPERUSER, priority=5)

# 通用命令执行处理器
command_handler = on_command("exec", permission=SUPERUSER, priority=5)

@device_handler.handle()
async def handle_devices(bot: Bot, event: MessageEvent) -> None:
    """查看当前启用的设备"""
    devices = await AccountManager.get_devices()
    if not devices:
        await device_handler.finish("当前没有启用的设备")
        return
    
    msg = "当前启用的设备:\n" + "\n".join([f"设备 {d}" for d in devices])
    await device_handler.finish(msg)

@update_handler.handle()
async def handle_update(bot: Bot, event: MessageEvent) -> None:
    """处理更新命令"""
    await update_handler.send("开始更新账号信息...")
    success, msg = await AccountManager.update_accounts()
    await update_handler.finish(msg)

@fight_handler.handle()
async def handle_fight(bot: Bot, event: MessageEvent) -> None:
    """处理战斗命令"""
    args = str(event.get_message()).strip().split()
    if len(args) <= 1:
        await fight_handler.finish("请指定设备编号")
        return
        
    device = args[1]
    devices = await AccountManager.get_devices()
    if int(device) not in devices:
        await fight_handler.finish(f"设备 {device} 未启用或不存在")
        return
        
    success, msg = await AccountManager.start_fight(device)
    await fight_handler.finish(msg)

@command_handler.handle()
async def handle_command(bot: Bot, event: MessageEvent) -> None:
    """处理通用命令"""
    msg = str(event.get_message()).strip()
    cmd = msg[4:].strip()  # 去除"exec"前缀
    
    if not cmd:
        await command_handler.finish("请输入要执行的命令")
        return
    
    try:
        logger.info(f"Executing command: {cmd}")
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        output = result.stdout if result.stdout else result.stderr
        if output:
            if len(output) > 1000:
                for i in range(0, len(output), 1000):
                    await bot.send(event, output[i:i+1000])
            else:
                await command_handler.send(output)
    
    except Exception as e:
        await command_handler.finish(f"执行出错: {str(e)}")
        return
    
    await command_handler.finish("执行完成")

@screenshot_handler.handle()
async def handle_screenshot(bot: Bot, event: MessageEvent) -> None:
    """处理截图命令
    用法：获取截图 设备号
    """
    args = str(event.get_message()).strip().split()
    if len(args) <= 1:
        await screenshot_handler.finish("请指定设备编号")
        return
        
    device = args[1]
    
    try:
        # 检查设备是否存在
        devices = await AccountManager.get_devices()
        if int(device) not in devices:
            await screenshot_handler.finish(f"设备 {device} 未启用或不存在")
            return
        
        # 执行截图命令
        cmd = ["python", str(DLT_PATH), "mode", str(device), "screenshot"]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        
        if proc.returncode != 0:
            await screenshot_handler.finish(f"获取截图失败: {stderr.decode()}")
            return           
            
    except Exception as e:
        logger.error(f"Screenshot error: {str(e)}")
        await screenshot_handler.finish(f"执行出错: {str(e)}")