# quest.py
from nonebot import on_command
from nonebot.adapters.onebot.v11 import Message, MessageEvent
from nonebot.params import CommandArg
from nonebot.log import logger

from ..database.database_manager import QuestManager

# 注册命令
set_quest = on_command("设置关卡", priority=5, block=True)
query_quest = on_command("查询关卡", priority=5, block=True)
clear_quest = on_command("清空关卡", priority=5, block=True)

@set_quest.handle()
async def handle_set_quest(event: MessageEvent, args: Message = CommandArg()):
    """处理设置关卡命令"""
    qq_id = str(event.get_user_id())
    
    try:
        args_list = args.extract_plain_text().split(maxsplit=1)
        if len(args_list) != 2:
            await set_quest.send(
                "格式：设置关卡 账号序号 关卡列表\n"
                "示例：设置关卡 1 1-7*99 CA-5\n"
            )
            return
            
        account_index = args_list[0]
        quest_str = args_list[1]
        
        try:
            account_index = int(account_index)
        except ValueError:
            await set_quest.send("账号序号必须是数字！")
            return

        # 在更新前先获取原始关卡信息
        original_account = QuestManager.get_quest(qq_id, account_index)
        original_quests = original_account[0].quests if original_account else None

        # 使用QuestManager设置关卡
        account, message = QuestManager.set_quest(qq_id, account_index, quest_str)
        if not account:
            await set_quest.send(message)
            return
            
        msg = f"""已更新刷图关卡！
账号：{account.username}
序号：{account_index}
服务器：{'官服' if account.server == 'official' else 'B服'}
原关卡：{original_quests if original_quests else '未设置'}
新关卡：{quest_str}"""
        
        logger.info(f"User {qq_id} set quests for account {account.username}: {quest_str}")
        await set_quest.send(msg)
            
    except Exception as e:
        logger.error(f"Error in set_quest: {e}")
        await set_quest.send(f"设置关卡失败：{str(e)}")

@query_quest.handle()
async def handle_query_quest(event: MessageEvent, args: Message = CommandArg()):
    """处理查询关卡命令"""
    qq_id = str(event.get_user_id())
    
    try:
        account_index = args.extract_plain_text().strip()
        
        if account_index:
            try:
                account_index = int(account_index)
            except ValueError:
                await query_quest.send("账号序号必须是数字！")
                return

        # 使用QuestManager获取关卡信息
        accounts = QuestManager.get_quest(qq_id, account_index if account_index else None)
        
        if not accounts:
            await query_quest.send(f"未找到账号信息！")
            return
            
        if account_index:
            # 显示单个账号信息
            account = accounts[0]
            msg = f"""账号关卡信息：
序号：{account.account_index}
用户名：{account.username}
服务器：{'官服' if account.server == 'official' else 'B服'}
当前关卡：{account.quests if account.quests else "未设置"}"""
        else:
            # 显示所有账号信息
            msg = "账号关卡信息：\n"
            for account in accounts:
                server_name = "官服" if account.server == "official" else "B服"
                msg += f"{account.account_index}. {account.username} ({server_name})"
                msg += f" - 关卡：{account.quests if account.quests else '未设置'}\n"
        
        await query_quest.send(msg.strip())
            
    except Exception as e:
        logger.error(f"Error in query_quest: {e}")
        await query_quest.send(f"查询关卡失败：{str(e)}")

@clear_quest.handle()
async def handle_clear_quest(event: MessageEvent, args: Message = CommandArg()):
    """处理清空关卡命令"""
    qq_id = str(event.get_user_id())
    
    try:
        account_index = args.extract_plain_text().strip()
        if not account_index:
            await clear_quest.send("请提供要清空关卡的账号序号！\n格式：清空关卡 账号序号")
            return
            
        try:
            account_index = int(account_index)
        except ValueError:
            await clear_quest.send("账号序号必须是数字！")
            return
            
        # 使用QuestManager清空关卡
        account, message = QuestManager.clear_quest(qq_id, account_index)
        if not account:
            await clear_quest.send(message)
            return
            
        msg = f"""已清空关卡设置！
账号：{account.username}
序号：{account_index}
服务器：{'官服' if account.server == 'official' else 'B服'}
原关卡：{account.quests if account.quests else "未设置"}"""
        
        logger.info(f"User {qq_id} cleared quests for account {account.username}")
        await clear_quest.send(msg)
            
    except Exception as e:
        logger.error(f"Error in clear_quest: {e}")
        await clear_quest.send(f"清空关卡失败：{str(e)}")